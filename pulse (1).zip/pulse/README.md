# PULSE · Notizie delle ultime 24 ore

**PULSE** è un aggregatore di notizie italiane in un **unico file HTML**: zero build, zero dipendenze, zero backend. Le notizie sono **vere** e arrivano da feed RSS pubblici di testate italiane, aggiornate in automatico.

## ✨ Funzionalità

- 📰 **Notizie reali** da 11 fonti: ANSA, Sky TG24, Repubblica, Wired Italia, Everyeye, Il Sole 24 Ore, Gazzetta dello Sport (e sezioni dedicate ANSA per Tecnologia, Politica, Economia, Sport, Cultura)
- ⚡ **Aggiornamento automatico** ogni 5 / 10 / 15 / 30 minuti + tasto "Aggiorna ora"
- 📸 **Foto ufficiali** degli articoli (dal feed o dalla pagina dell'articolo)
- 🗂️ **7 categorie**: Tutte, Tecnologia, Gaming, Politica, Economia, Sport, Cultura
- 🔎 **Ricerca istantanea** tra i titoli (scorciatoia `Ctrl+K`)
- 🎨 **19 temi** (13 scuri + 6 chiari) con transizione morbida a tutta pagina (View Transitions API)
- 🔖 **Segnalibri** persistenti
- 👤 **Account locale sicuro**: password cifrate (SHA-256 + sale casuale), sessioni con scadenza, "ricordami" 30 giorni, blocco anti-tentativi, esportazione/ripristino backup
- 🔊 **Effetti sonori** UI generati con Web Audio (nessun file audio)
- 📱 **Responsive**: desktop, tablet e mobile
- ️ Micro-interazioni: tilt 3D delle card, zoom soft, skeleton loading

## 🚀 Come usarlo

### In locale

Basta aprire `index.html` con doppio clic nel browser, oppure:

```bash
# opzionale: server locale
python3 -m http.server 8000
# poi apri http://localhost:8000
```

### Su GitHub Pages

1. Crea un nuovo repository su GitHub (es. `pulse`)
2. Carica il contenuto di questa cartella (oppure `git clone` + `git push`)
3. Nel repo: **Settings → Pages → Build and deployment → Source: Deploy from a branch**
4. Scegli branch `main` / directory `/ (root)` e salva
5. Dopo qualche minuto il sito sarà online su:
   `https://<tuo-username>.github.io/pulse/`

> Se vuoi usare il **GitHub User/Organization site** (`https://<username>.github.io/`) il file principale deve essere `index.html` alla radice: qui è già così.

### Da questo zip

Scompatta la zip in una cartella pulita e procedi come sopra.

## ⚙️ Note tecniche

- Tutto (HTML + CSS + JS + immagini) è **incorporato in un solo file** (~1 MB): non ci sono asset esterni da gestire.
- I feed RSS vengono letti lato client tramite **proxy CORS pubblici** (rss2json, allorigins, codetabs). Se una fonte o un proxy non risponde, la sua notizia semplicemente non compare: l'app riprova automaticamente.
- Gli account e i preferiti sono salvati nel **localStorage** del browser (niente server, niente invio di dati a terzi).
- Funziona da qualsiasi host statico: GitHub Pages, Netlify, Vercel, Cloudflare Pages, un semplice FTP.

## 📄 Licenza

[MIT](LICENSE) — puoi usarlo, modificarlo e ridistribuirlo liberamente.
